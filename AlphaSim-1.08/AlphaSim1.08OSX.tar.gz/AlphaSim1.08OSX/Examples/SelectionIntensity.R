#! /usr/bin/env Rscript

##Load libraries
#library(doBy)
#library(plyr)

TbvVarTbv <- matrix(nrow=1, ncol=4)
AdditiveGeneticVariance <- matrix(nrow=1, ncol=2)

dir.create("Figures")
E <- c("Replication1/Base/OnePercentSelection","Replication1/Base/TwentyPercentSelection")
initial=getwd()
EI <- 0
for (e in E) {
  EI <- EI + 1
  SelDir <- (paste(E[EI], "/SimulatedData", sep=""))
  print(SelDir)
  if (file.exists(SelDir)) {
    setwd(SelDir)
    ## Calculate aditive genetic variance in base population
    y <- matrix(data=scan(file="UnrestrictedQtnInformation.txt", nlines=1000, nmax=1000*8, skip=1), 
                nrow=1000, ncol=8, byrow=TRUE)
    z <- matrix(data=scan(file="UnrestrictedQtnAdditEffects.txt", nlines=1000, nmax=1000*4, skip=1), 
                nrow=1000, ncol=4, byrow=TRUE)
    tmpvarqtl <- cbind(e, sum(2*y[,4]*(1-y[,4])*z[,4]^2))
    AdditiveGeneticVariance <- rbind(AdditiveGeneticVariance, tmpvarqtl)

    ## Calculate average genetic value and its variance in each generation 
    print(E[EI])
                                
    x <- matrix(data=scan(file="PedigreeAndGeneticValues.txt", nlines=2000, nmax=2000*12, skip=1),
                nrow=2000, ncol=12, byrow=TRUE)
    Gen <- 10

    freq <- matrix(nrow=1,ncol=3)

    for (i in 1:Gen) {
      tmprow <- vector()
      tmprow <- cbind(tmprow,i)
      tmp <- mean(x[(i*200-199):(i*200),9])
      tmprow <- cbind(tmprow,tmp)
      tmp <- var(x[(i*200-199):(i*200),9])
      tmprow <- cbind(tmprow,tmp)
      freq <- rbind(freq,tmprow)
    }
  setwd(initial)
  }
freq <- freq[-1,]
tmp <- cbind(as.matrix(rep(e,Gen),nrow=Gen, ncol=1), freq)
TbvVarTbv <- rbind(TbvVarTbv, tmp)
}

AdditiveGeneticVariance <- AdditiveGeneticVariance[-1,]
TbvVarTbv <- TbvVarTbv[-1,]

#setwd("/exports/eddie/scratch/jjenko/TestForJohn")

#write.table(AdditiveGeneticVariance, "AdditiveGeneticVarianceBaseGeneration.txt", row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE)
#write.table(TbvVarTbv, "TbvVarTbv.txt", row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE)

######################
## Plot the results ##
######################

color <- c("#377eb8","#e41a1c","#000000","#4daf4a","#984ea3")

## Read the data of genetic gain and genic variance
dataTBV <- data.frame(TbvVarTbv)
dataTBV <- data.frame(lapply(dataTBV, as.character), stringsAsFactors=FALSE)
dataTBV[,-1] <- data.frame(lapply(dataTBV[,-1], as.numeric), stringsAsFactors=FALSE)

names(dataTBV) <- c("edit", "generation", "gebv","varEBVTBV")

#setwd("C:/Users/jjenko/Dokumenti/EDDIE/jjenkoVer2/genome_editing")

## Add a column of genetic variance in generation 1 and TBV in generation 1
dataTBV <- merge(dataTBV, dataTBV[dataTBV$generation==1, c(1,4,3)], by=c("edit"))
names(dataTBV)[c(3:6)] <- c("gebv","varEBVTBV","vartr1","gebvgen1")

## Standardize TBV on genetic variance of first generation only
dataTBV$sgebv <- (dataTBV$gebv - dataTBV$gebvgen1) / sqrt(dataTBV$vartr1)

#####################################################################################################################################################
pdf(file=paste("Figures/SelIntens.pdf", sep=""), width=12/2.54,height=10/2.54, pointsize=12, encoding="CP1250")
par(mgp=c(2.5,1,0), mar=c(4, 4, 1, 1))
ymax       <- range(dataTBV[dataTBV$edit=="Replication1/Base/OnePercentSelection",]$sgebv)[2]
plot(c(1:10),rnorm(10, mean=5, sd=1), ylim=c(0,ymax),
     axes=FALSE, type='o', col="white", xaxt = "n", pch = 1, xlab="Generation", ylab="Genetic gain")
lines(dataTBV[dataTBV$edit=="Replication1/Base/TwentyPercentSelection", ]$generation, 
      dataTBV[dataTBV$edit=="Replication1/Base/TwentyPercentSelection", ]$sgebv, 
      type='l', col=color[1], bg='white', lty=1, lwd=2)
lines(dataTBV[dataTBV$edit=="Replication1/Base/OnePercentSelection", ]$generation, 
      dataTBV[dataTBV$edit=="Replication1/Base/OnePercentSelection", ]$sgebv,
      type='l', col=color[2], bg='white', lty=1, lwd=2)
xlabels <- as.character(c(1:10))
ylables <- c(seq(0,50, by=2))
axis(1, at=c(1:10), lab=xlabels, pos=-0.63)
axis(2, at=c(seq(0,50, by=2)), las=1)
text(3, ymax-0.1, "Selection intensity")
legend(1.5, ymax-0.2, c("20%", "1%"), cex=1,
       col=c(color[c(1,2)]), text.col = c("black"), pt.bg=c("white"),lty=1, bty="n", bg="white", ncol=1, lwd=2)
#box()  
dev.off()
