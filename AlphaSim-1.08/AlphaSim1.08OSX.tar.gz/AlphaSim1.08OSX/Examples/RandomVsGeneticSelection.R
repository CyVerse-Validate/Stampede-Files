#!/usr/bin/env Rscript

### Summarize Results Scenarios
### Oct 15 - MBattagin, GGorjanc, JHickey
####Converted for use with the GUI - October 2016 - D de Búrca

## Packages, Variables and Files --------------------
#install.packages("ggplot2")

library("ggplot2")

print(getwd())

TBV=read.table("Replication1/Base/Random/SimulatedData/GeneticMeansPerGeneration.txt", header=T)
GenVar=read.table("Replication1/Base/Random/SimulatedData/TotalGenicAndGeneticVariancesPerGeneration.txt", header=T)

## Edit files ----------------------------------------
TBV=TBV[which(TBV$QTNmodel==1),c("Generation","meanGv")]

GenVar=GenVar[which(GenVar$QtnModel==1),c("Generation","TotalGeneticVar1")]

## Calculate Response to Selection
TBV$RespSel=(TBV$meanGv-TBV$meanGv[1])/sqrt(GenVar$TotalGeneticVar1[1])

## Genetic Variance
GenVar$GenVarStd=GenVar$TotalGeneticVar1/GenVar$TotalGeneticVar1[1]

## Plots basic ---------------------------------------
#file <- paste0("Figures/ResponseToSelectionNoSel.pdf")
#pdf(file = file)

basicRS <- ggplot(TBV, aes(x=Generation, y=RespSel))
basicRS <- basicRS + geom_line(colour = "red", size=2) 
basicRS <- basicRS + scale_x_continuous(breaks=1:21) + ylim(-1,10) + xlab("Generation") + ylab("Response to selection")
basicRS <- basicRS + theme_bw(base_size = 18, base_family = "") + theme(axis.title=element_text(size=12),
                                                                        axis.text=element_text(size=12),
                                                                        panel.background = element_rect(fill = "white"),
                                                                        panel.grid.major = element_blank(), 
                                                                        panel.grid.minor = element_blank())
#print(basicRS)

#dev.off()

#file <- paste0("Figures/GeneticVarianceNoSel.pdf")
#pdf(file = file)

basicGV <- ggplot(GenVar, aes(x=Generation, y=GenVarStd))
basicGV <- basicGV + geom_line(colour = "red", size=2) 
basicGV <- basicGV + scale_x_continuous(breaks=1:21) + ylim(0,2) + xlab("Generation") + ylab("Genetic variance")
basicGV <- basicGV + theme_bw(base_size = 18, base_family = "") + theme(axis.title=element_text(size=12),
                                                                        axis.text=element_text(size=12),
                                                                        panel.background = element_rect(fill = "white"),
                                                                        panel.grid.major = element_blank(), 
                                                                        panel.grid.minor = element_blank())
#print(basicGV)

#dev.off()

#rm(TBV,GenVar)

### Genetic Selection --------------------------------------------------
fileTBV="Replication1/Base/SelectionScenario/SimulatedData/GeneticMeansPerGeneration.txt"
fileVAR="Replication1/Base/SelectionScenario/SimulatedData/TotalGenicAndGeneticVariancesPerGeneration.txt"
if (!file.exists("Figures"))
{
  dir.create(file.path("Figures"))
}
if (file.exists(fileTBV)){
  if (file.exists(fileVAR)){
    TBV=read.table(fileTBV, header=T)
    GenVar=read.table(fileVAR, header=T)
    
    ## Edit files ----------------------------------------
    TBV=TBV[which(TBV$QTNmodel==1),c("Generation","meanGv")]
    
    GenVar=GenVar[which(GenVar$QtnModel==1),c("Generation","TotalGeneticVar1")]
    
    ## Calculate Response to Selection
    TBV$RespSel=(TBV$meanGv-TBV$meanGv[1])/sqrt(GenVar$TotalGeneticVar1[1])
    
    ## Genetic Variance
    GenVar$GenVarStd=GenVar$TotalGeneticVar1/GenVar$TotalGeneticVar1[1]
    
    ## Plots basic ---------------------------------------
    file <- paste0("Figures/ResponseToSelection.pdf")
    pdf(file = file)
    
    GenEditRS <- basicRS + geom_line(size=2, colour="blue", data=TBV,aes(x=Generation, y=RespSel))
    print(GenEditRS)
    
    dev.off()
    
    
    file <- paste0("Figures/GeneticVariance.pdf")
    pdf(file = file)
    
    GenEditGV <- basicGV + geom_line(size=2, colour="blue", data=GenVar,aes(x=Generation, y=GenVarStd))
    print(GenEditGV)
    
    dev.off()
  }
}

rm(TBV,GenVar)

