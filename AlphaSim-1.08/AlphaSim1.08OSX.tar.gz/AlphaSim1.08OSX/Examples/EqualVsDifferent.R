#! /usr/bin/env Rscript

##Load libraries
#library(doBy)
#library(plyr)
#library(sqldf)

TbvVarTbv <- matrix(nrow=1, ncol=10)
AdditiveGeneticVariance <- matrix(nrow=1, ncol=5)

E <- c("Replication1/Base/Equal", "Replication1/Base/Different")

EI <- 0
initial <- getwd()
dir.create("Figures")
for (e in E) {
  EI <- EI + 1
  SelDir <- (paste(E[EI], "/SimulatedData", sep=""))
  print(SelDir)
  if (file.exists(SelDir)) {
    setwd(SelDir)
    ## Calculate aditive genetic variance in base population
    y <- matrix(data=scan(file="UnrestrictedQtnInformation.txt", nlines=1000, nmax=1000*8, skip=1), 
                nrow=1000, ncol=8, byrow=TRUE)
    z <- matrix(data=scan(file="UnrestrictedQtnAdditEffects.txt", nlines=1000, nmax=1000*7, skip=1), 
                nrow=1000, ncol=7, byrow=TRUE)
    tmpvarqtl <- cbind(e, sum(2*y[,4]*(1-y[,4])*z[,4]^2), sum(2*y[,4]*(1-y[,4])*z[,5]^2), sum(2*y[,4]*(1-y[,4])*z[,6]^2), sum(2*y[,4]*(1-y[,4])*z[,7]^2))
    AdditiveGeneticVariance <- rbind(AdditiveGeneticVariance, tmpvarqtl)
    
    ## Calculate average genetic value and its variance in each generation 
    print(E[EI])
    
    x <- matrix(data=scan(file="PedigreeAndGeneticValues.txt", nlines=2000, nmax=2000*36, skip=1),
                nrow=2000, ncol=36, byrow=TRUE)
    Gen <- 10
    
    freq <- NULL
    
    for (i in 1:Gen) {
      tmprow <- vector()
      tmprow <- cbind(tmprow,i)
      tmp <- mean(x[(i*200-199):(i*200),21])
      tmprow <- cbind(tmprow,tmp)
      tmp <- var(x[(i*200-199):(i*200),21])
      tmprow <- cbind(tmprow,tmp)
      tmp <- mean(x[(i*200-199):(i*200),23])
      tmprow <- cbind(tmprow,tmp)
      tmp <- var(x[(i*200-199):(i*200),23])
      tmprow <- cbind(tmprow,tmp)
      tmp <- mean(x[(i*200-199):(i*200),25])
      tmprow <- cbind(tmprow,tmp)
      tmp <- var(x[(i*200-199):(i*200),25])
      tmprow <- cbind(tmprow,tmp)
      tmp <- mean(x[(i*200-199):(i*200),27])
      tmprow <- cbind(tmprow,tmp)
      tmp <- var(x[(i*200-199):(i*200),27])
      tmprow <- cbind(tmprow,tmp)
      freq <- rbind(freq,tmprow)
    }
  setwd(initial)
  }
 # freq <- freq[-1,]
   print(Gen)
  tmp <- cbind(as.matrix(rep(e,Gen),nrow=Gen, ncol=1), freq)
  TbvVarTbv <- rbind(TbvVarTbv, tmp)
}

AdditiveGeneticVariance <- AdditiveGeneticVariance[-1,]
TbvVarTbv <- TbvVarTbv[-1,]

#setwd("/exports/eddie/scratch/jjenko/TestForJohn")

#write.table(AdditiveGeneticVariance, "AdditiveGeneticVarianceBaseGenerationFourTraits.txt", row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE)
#write.table(TbvVarTbv, "TbvVarTbvFourTraits.txt", row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE)

######################
## Plot the results ##
######################

color <- c("#377eb8","#e41a1c","#000000","#4daf4a","#984ea3")

## Read the data of genetic gain and genic variance
dataTBV <- data.frame(TbvVarTbv)
dataTBV <- data.frame(lapply(dataTBV, as.character), stringsAsFactors=FALSE)
dataTBV[,-1] <- data.frame(lapply(dataTBV[,-1], as.numeric), stringsAsFactors=FALSE)

names(dataTBV) <- c("edit", "generation", "gebv1","varEBVTBV1", "gebv2","varEBVTBV2", "gebv3","varEBVTBV3", "gebv4","varEBVTBV4")

## Add a column of genetic variance in generation 1 and TBV in generation 1
dataTBV <- merge(dataTBV, dataTBV[dataTBV$generation==1, c(1,4,3)], by=c("edit"))
dataTBV <- merge(dataTBV, dataTBV[dataTBV$generation==1, c(1,6,5)], by=c("edit"))
dataTBV <- merge(dataTBV, dataTBV[dataTBV$generation==1, c(1,8,7)], by=c("edit"))
dataTBV <- merge(dataTBV, dataTBV[dataTBV$generation==1, c(1,10,9)], by=c("edit"))
names(dataTBV)[c(3:18)] <- c("gebv1","varEBVTBV1","gebv2","varEBVTBV2","gebv3","varEBVTBV3","gebv4","varEBVTBV4","vartr1g1","gebvgen1g1","vartr2g1","gebvgen2g1","vartr3g1","gebvgen3g1","vartr4g1","gebvgen4g1")

## Standardize TBV on genetic variance of first generation only
dataTBV$sgebv1 <- (dataTBV$gebv1 - dataTBV$gebvgen1g1) / sqrt(dataTBV$vartr1g1)
dataTBV$sgebv2 <- (dataTBV$gebv2 - dataTBV$gebvgen2g1) / sqrt(dataTBV$vartr2g1)
dataTBV$sgebv3 <- (dataTBV$gebv3 - dataTBV$gebvgen3g1) / sqrt(dataTBV$vartr3g1)
dataTBV$sgebv4 <- (dataTBV$gebv4 - dataTBV$gebvgen4g1) / sqrt(dataTBV$vartr4g1)

dataTBV$sgebvAll <- dataTBV$sgebv1 + dataTBV$sgebv2 + dataTBV$sgebv3 + dataTBV$sgebv4

#####################################################################################################################################################
pdf(file=paste("Figures/FourTraits.pdf", sep=""), width=12/2.54,height=10/2.54, pointsize=12, encoding="CP1250")
par(mgp=c(2.5,1,0), mar=c(4, 4, 1, 1))
ymax       <- range(dataTBV$sgebv1)[2]+1
ymin       <- range(dataTBV$sgebv4)[1]
plot(c(1:10),rnorm(10, mean=5, sd=1), ylim=c(ymin,ymax),
     axes=FALSE, type='o', col="white", xaxt = "n", pch = 1, xlab="Generation", ylab="Genetic gain")
lines(dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$generation, 
      dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$sgebv1, 
      type='l', col=color[1], bg='white', lty=1, lwd=2)
lines(dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$generation, 
      dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$sgebv2,
      type='l', col=color[2], bg='white', lty=1, lwd=2)
lines(dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$generation, 
      dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$sgebv3,
      type='l', col=color[3], bg='white', lty=1, lwd=2)
lines(dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$generation, 
      dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$sgebv4,
      type='l', col=color[4], bg='white', lty=1, lwd=2)
lines(dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$generation, 
      dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$sgebv1, 
      type='l', col=color[1], bg='white', lty=2, lwd=2)
lines(dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$generation, 
      dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$sgebv2,
      type='l', col=color[2], bg='white', lty=2, lwd=2)
lines(dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$generation, 
      dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$sgebv3,
      type='l', col=color[3], bg='white', lty=2, lwd=2)
lines(dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$generation, 
      dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$sgebv4,
      type='l', col=color[4], bg='white', lty=2, lwd=2)
xlabels <- as.character(c(1:10))
ylables <- c(seq(0,50, by=5))
axis(1, at=c(1:10), lab=xlabels)
axis(2, at=c(seq(0,20, by=1)), las=1)
text(3, ymax-0.1, "Index, Trait, Accuracy, Weight", cex=0.7)
legend(1, ymax-0.2, c("1, 1, 1.0, 0.25", "1, 2, 0.7, 0.25", "1, 3, 0.5, 0.25", "1, 4, 0.1, 0.25", NA, "2, 1, 1, 0.25", "2, 2, 1, 0.25", "2, 3, 1, 0.25", "2, 4, 1, 0.25"), cex=0.7,
       col=c(color[c(1,2,3,4,NA)]), text.col = c("black"), pt.bg=c("white"),lty=c(1,1,1,1,NA,2,2,2,2), bty="n", bg="white", ncol=1, lwd=2)
#box()  
dev.off()


#####################################################################################################################################################
pdf(file=paste("Figures/FourTraitsIndex.pdf", sep=""), width=12/2.54,height=10/2.54, pointsize=12, encoding="CP1250")
par(mgp=c(2.5,1,0), mar=c(4, 4, 1, 1))
ymax       <- range(dataTBV$sgebvAll)[2]+3
plot(c(1:10),rnorm(10, mean=5, sd=1), ylim=c(0,ymax),
     axes=FALSE, type='o', col="white", xaxt = "n", pch = 1, xlab="Generation", ylab="Genetic gain")
lines(dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$generation, 
      dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$sgebvAll, 
      type='l', col=color[1], bg='white', lty=1, lwd=2)
lines(dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$generation, 
      dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$sgebvAll,
      type='l', col=color[1], bg='white', lty=2, lwd=2)
# lines(sum_dataTBV[sum_dataTBV$gdet==gd[3] & sum_dataTBV$edit==edit[2] & sum_dataTBV$generation > 20, ]$generation - 20, 
#       sum_dataTBV[sum_dataTBV$gdet==gd[3] & sum_dataTBV$edit==edit[2] & sum_dataTBV$generation > 20, ]$sgebv - axis2start,
#       type='l', col="#969696", bg='white', lty=1, lwd=2)
xlabels <- as.character(c(1:10))
ylables <- c(seq(0,50, by=10))
axis(1, at=c(1:10), lab=xlabels)
axis(2, at=c(seq(0,50, by=2)), las=1)
text(1.5, ymax-1, "Index", cex=0.7)
legend(1, ymax-1.5, c("1 - four traits with accuracy: 1.0, 0.7, 0.5, and 0.1", "2 - four traits with accuracy: 1.0 each"), cex=0.7,
       col=color[1], text.col = c("black"), pt.bg=c("white"),lty=c(1,2), bty="n", bg="white", ncol=1, lwd=2)
#box()  
dev.off()

print("Plots are printed out successfully")

























#    ## With 10 000 QTN per animal
#    
#    ##Load libraries
#    #library(doBy)
#    #library(plyr)
#    #library(sqldf)
#    
#    TbvVarTbv <- matrix(nrow=1, ncol=10)
#    AdditiveGeneticVariance <- matrix(nrow=1, ncol=5)
#    
#    E <- c("Replication1/Base/Equal", "Replication1/Base/Different")
#    
#    EI <- 0
#    for (e in E) {
#      EI <- EI + 1
#      SelDir <- (paste(E[EI], "/SimulatedData", sep=""))
#      print(SelDir)
#      if (file.exists(SelDir)) {
#        setwd(SelDir)
#        ## Calculate aditive genetic variance in base population
#        y <- matrix(data=scan(file="UnrestrictedQtnInformation.txt", nlines=10000, nmax=10000*8, skip=1), 
#                    nrow=10000, ncol=8, byrow=TRUE)
#        z <- matrix(data=scan(file="UnrestrictedQtnAdditEffects.txt", nlines=10000, nmax=10000*7, skip=1), 
#                    nrow=10000, ncol=7, byrow=TRUE)
#        tmpvarqtl <- cbind(e, sum(2*y[,4]*(1-y[,4])*z[,4]^2), sum(2*y[,4]*(1-y[,4])*z[,5]^2), sum(2*y[,4]*(1-y[,4])*z[,6]^2), sum(2*y[,4]*(1-y[,4])*z[,7]^2))
#        AdditiveGeneticVariance <- rbind(AdditiveGeneticVariance, tmpvarqtl)
#        
#        ## Calculate average genetic value and its variance in each generation 
#        print(E[EI])
#        
#        x <- matrix(data=scan(file="PedigreeAndGeneticValues.txt", nlines=10000, nmax=10000*28, skip=1),
#                    nrow=10000, ncol=28, byrow=TRUE)
#        Gen <- 10
#        
#        freq <- matrix(nrow=1,ncol=9)
#        
#        for (i in 1:Gen) {
#          tmprow <- vector()
#          tmprow <- cbind(tmprow,i)
#          tmp <- mean(x[(i*1000-999):(i*1000),5])
#          tmprow <- cbind(tmprow,tmp)
#          tmp <- var(x[(i*1000-999):(i*1000),5])
#          tmprow <- cbind(tmprow,tmp)
#          tmp <- mean(x[(i*1000-999):(i*1000),7])
#          tmprow <- cbind(tmprow,tmp)
#          tmp <- var(x[(i*1000-999):(i*1000),7])
#          tmprow <- cbind(tmprow,tmp)
#          tmp <- mean(x[(i*1000-999):(i*1000),9])
#          tmprow <- cbind(tmprow,tmp)
#          tmp <- var(x[(i*1000-999):(i*1000),9])
#          tmprow <- cbind(tmprow,tmp)
#          tmp <- mean(x[(i*1000-999):(i*1000),11])
#          tmprow <- cbind(tmprow,tmp)
#          tmp <- var(x[(i*1000-999):(i*1000),11])
#          tmprow <- cbind(tmprow,tmp)
#          freq <- rbind(freq,tmprow)
#        }
#      setwd("../../")
#      }
#      freq <- freq[-1,]
#      tmp <- cbind(as.matrix(rep(e,Gen),nrow=Gen, ncol=1), freq)
#      TbvVarTbv <- rbind(TbvVarTbv, tmp)
#    }
#    
#    AdditiveGeneticVariance <- AdditiveGeneticVariance[-1,]
#    TbvVarTbv <- TbvVarTbv[-1,]
#    
#    #setwd("/exports/eddie/scratch/jjenko/TestForJohn")
#    
#    #write.table(AdditiveGeneticVariance, "AdditiveGeneticVarianceBaseGenerationFourTraits.txt", row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE)
#    #write.table(TbvVarTbv, "TbvVarTbvFourTraits.txt", row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE)
#    
#    ######################
#    ## Plot the results ##
#    ######################
#    
#    color <- c("#377eb8","#e41a1c","#000000","#4daf4a","#984ea3")
#    
#    ## Read the data of genetic gain and genic variance
#    dataTBV <- data.frame(TbvVarTbv)
#    dataTBV <- data.frame(lapply(dataTBV, as.character), stringsAsFactors=FALSE)
#    dataTBV[,-1] <- data.frame(lapply(dataTBV[,-1], as.numeric), stringsAsFactors=FALSE)
#    
#    names(dataTBV) <- c("edit", "generation", "gebv1","varEBVTBV1", "gebv2","varEBVTBV2", "gebv3","varEBVTBV3", "gebv4","varEBVTBV4")
#    
#    ## Add a column of genetic variance in generation 1 and TBV in generation 1
#    dataTBV <- merge(dataTBV, dataTBV[dataTBV$generation==1, c(1,4,3)], by=c("edit"))
#    dataTBV <- merge(dataTBV, dataTBV[dataTBV$generation==1, c(1,6,5)], by=c("edit"))
#    dataTBV <- merge(dataTBV, dataTBV[dataTBV$generation==1, c(1,8,7)], by=c("edit"))
#    dataTBV <- merge(dataTBV, dataTBV[dataTBV$generation==1, c(1,10,9)], by=c("edit"))
#    names(dataTBV)[c(3:18)] <- c("gebv1","varEBVTBV1","gebv2","varEBVTBV2","gebv3","varEBVTBV3","gebv4","varEBVTBV4","vartr1g1","gebvgen1g1","vartr2g1","gebvgen2g1","vartr3g1","gebvgen3g1","vartr4g1","gebvgen4g1")
#    
#    ## Standardize TBV on genetic variance of first generation only
#    dataTBV$sgebv1 <- (dataTBV$gebv1 - dataTBV$gebvgen1g1) / sqrt(dataTBV$vartr1g1)
#    dataTBV$sgebv2 <- (dataTBV$gebv2 - dataTBV$gebvgen2g1) / sqrt(dataTBV$vartr2g1)
#    dataTBV$sgebv3 <- (dataTBV$gebv3 - dataTBV$gebvgen3g1) / sqrt(dataTBV$vartr3g1)
#    dataTBV$sgebv4 <- (dataTBV$gebv4 - dataTBV$gebvgen4g1) / sqrt(dataTBV$vartr4g1)
#    
#    dataTBV$sgebvAll <- dataTBV$sgebv1 + dataTBV$sgebv2 + dataTBV$sgebv3 + dataTBV$sgebv4
#    
#    #####################################################################################################################################################
#    pdf(file=paste("Figures/FourTraits.pdf", sep=""), width=12/2.54,height=10/2.54, pointsize=12, encoding="CP1250")
#    par(mgp=c(2.5,1,0), mar=c(4, 4, 1, 1))
#    ymax       <- range(dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$sgebv1)[2]+1
#    plot(c(1:10),rnorm(10, mean=5, sd=1), ylim=c(0,ymax),
#         axes=FALSE, type='o', col="white", xaxt = "n", pch = 1, xlab="Generation", ylab="Genetic gain")
#    lines(dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$generation, 
#          dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$sgebv1, 
#          type='l', col=color[1], bg='white', lty=1, lwd=2)
#    lines(dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$generation, 
#          dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$sgebv2,
#          type='l', col=color[2], bg='white', lty=1, lwd=2)
#    lines(dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$generation, 
#          dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$sgebv3,
#          type='l', col=color[3], bg='white', lty=1, lwd=2)
#    lines(dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$generation, 
#          dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$sgebv4,
#          type='l', col=color[4], bg='white', lty=1, lwd=2)
#    lines(dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$generation, 
#          dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$sgebv1, 
#          type='l', col=color[1], bg='white', lty=2, lwd=2)
#    lines(dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$generation, 
#          dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$sgebv2,
#          type='l', col=color[2], bg='white', lty=2, lwd=2)
#    lines(dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$generation, 
#          dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$sgebv3,
#          type='l', col=color[3], bg='white', lty=2, lwd=2)
#    lines(dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$generation, 
#          dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$sgebv4,
#          type='l', col=color[4], bg='white', lty=2, lwd=2)
#    xlabels <- as.character(c(1:10))
#    ylables <- c(seq(0,50, by=5))
#    axis(1, at=c(1:10), lab=xlabels)
#    axis(2, at=c(seq(0,20, by=1)), las=1)
#    text(3, ymax-0.1, "Index, Trait, Accuracy, Weight", cex=0.7)
#    legend(1, ymax-0.2, c("1, 1, 1.0, 0.25", "1, 2, 0.7, 0.25", "1, 3, 0.5, 0.25", "1, 4, 0.1, 0.25", NA, "2, 1, 1, 0.25", "2, 2, 1, 0.25", "2, 3, 1, 0.25", "2, 4, 1, 0.25"), cex=0.7,
#           col=c(color[c(1,2,3,4,NA)]), text.col = c("black"), pt.bg=c("white"),lty=c(1,1,1,1,NA,2,2,2,2), bty="n", bg="white", ncol=1, lwd=2)
#    #box()  
#    dev.off()
#    
#    
#    #####################################################################################################################################################
#    pdf(file=paste("Figures/FourTraitsIndex.pdf", sep=""), width=12/2.54,height=10/2.54, pointsize=12, encoding="CP1250")
#    par(mgp=c(2.5,1,0), mar=c(4, 4, 1, 1))
#    ymax       <- range(dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$sgebvAll)[2]+3
#    plot(c(1:10),rnorm(10, mean=5, sd=1), ylim=c(0,ymax),
#         axes=FALSE, type='o', col="white", xaxt = "n", pch = 1, xlab="Generation", ylab="Genetic gain")
#    lines(dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$generation, 
#          dataTBV[dataTBV$edit=="Replication1/Base/Different", ]$sgebvAll, 
#          type='l', col=color[1], bg='white', lty=1, lwd=2)
#    lines(dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$generation, 
#          dataTBV[dataTBV$edit=="Replication1/Base/Equal", ]$sgebvAll,
#          type='l', col=color[1], bg='white', lty=2, lwd=2)
#    # lines(sum_dataTBV[sum_dataTBV$gdet==gd[3] & sum_dataTBV$edit==edit[2] & sum_dataTBV$generation > 20, ]$generation - 20, 
#    #       sum_dataTBV[sum_dataTBV$gdet==gd[3] & sum_dataTBV$edit==edit[2] & sum_dataTBV$generation > 20, ]$sgebv - axis2start,
#    #       type='l', col="#969696", bg='white', lty=1, lwd=2)
#    xlabels <- as.character(c(1:10))
#    ylables <- c(seq(0,50, by=10))
#    axis(1, at=c(1:10), lab=xlabels)
#    axis(2, at=c(seq(0,50, by=2)), las=1)
#    text(1.5, ymax-1, "Index", cex=0.7)
#    legend(1, ymax-1.5, c("1 - four traits with accuracy: 1.0, 0.7, 0.5, and 0.1", "2 - four traits with accuracy: 1.0 each"), cex=0.7,
#           col=color[1], text.col = c("black"), pt.bg=c("white"),lty=c(1,2), bty="n", bg="white", ncol=1, lwd=2)
#    #box()  
#    dev.off()
#    
#    print("Plots are printed out successfully")
#    
