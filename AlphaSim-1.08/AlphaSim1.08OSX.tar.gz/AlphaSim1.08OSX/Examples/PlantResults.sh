Home=$PWD
echo "  Step             = Summarise Results "
echo 
cd ${Home}/NoRecurrentSelection
echo "  Step             = Basic Scenario "
tail -6 output | head -2
echo
cd ${Home}/TwoCyclesRecurrentSelection
echo "  Step             = Two cycles of recurrent selection "
tail -6 output | head -2
echo
cd ${Home}/FourCyclesRecurrentSelection
echo "  Step             = Four cycles of recurrent selection "
tail -6 output | head -2
echo

